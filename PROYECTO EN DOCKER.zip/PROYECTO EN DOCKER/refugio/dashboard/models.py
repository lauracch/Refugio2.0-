from django.db import models
from django.contrib.auth.models import User 

#Create your models here. 
CATEGORY = (
    ('Rabia', 'Rabia'),
    ('Parvovirus', 'Parvovirus'),
    ('Hepatitis', 'Hepatitis'),
    ('Influenza', 'Influenza'),
    ('Distemper', 'Distemper'),
)


class listado_mascotas(models.Model):
    nombre = models.CharField( max_length=100, null=True)
    vacuna = models.CharField( max_length=20, choices=CATEGORY, null=True)
    edad = models.PositiveBigIntegerField(null=True)

    class Meta:
        verbose_name_plural = 'listado_mascotas'

    def __str__(self):
        return f'{self.nombre}-{self.vacuna}-{self.edad}'

class Product(models.Model):
    id = models.PositiveIntegerField(primary_key=True)
    nombre = models.CharField(max_length=100, null=True)
    sexo = models.CharField(max_length=100, null=True)
    vacuna = models.CharField(max_length=20, choices=CATEGORY,null=True)
    edad = models.PositiveIntegerField(null=True)
    fecha_rescate = models.DateField("Fecha de rescate: (DD/MM/AA)",auto_now_add=False, auto_now= False, blank=True,null=True)
    image = models.ImageField(default='avatar.jpg', upload_to = 'Profile_Images')

    class Meta: 
        verbose_name_plural = 'Product'

    def __str__ (self):
        return f'{self.nombre}-{self.edad}-{self.image}'



class Order(models.Model):
    nombre_de_mascota = models.ForeignKey(Product, on_delete=models.CASCADE, null=True)
    edad_solicitante = models.PositiveIntegerField(null=True)
    direccion = models.CharField(max_length=100, null=True)
    telefono = models.PositiveIntegerField(null=True)
    razones_para_adoptar= models.CharField(max_length=500, null=True)
    staff = models.ForeignKey(User, models.CASCADE, null=True)
    order_quantity = models.PositiveIntegerField(null=True)
    date = models.DateTimeField(auto_now_add=True)
    

    class Meta: 
        verbose_name_plural = 'Order'

    def __str__(self):
        return f'{self.order_quantity} order by {self.staff}'
