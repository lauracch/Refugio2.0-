from django import forms
from .models import Product, Order

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['id','nombre','vacuna','sexo', 'edad','fecha_rescate','image']

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['nombre_de_mascota','edad_solicitante','direccion','telefono','razones_para_adoptar']